import React from 'react';
import QRScanner from './QRScanner';

function App() {
  return (
    <div className="App">
      <h1>♻️ EcoChain – Recycle, Earn, Repeat</h1>
      <QRScanner />
    </div>
  );
}

export default App;