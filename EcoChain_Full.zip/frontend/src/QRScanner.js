import React from 'react';

const QRScanner = () => {
  return (
    <div>
      <p>QR Scanner Placeholder</p>
    </div>
  );
};

export default QRScanner;