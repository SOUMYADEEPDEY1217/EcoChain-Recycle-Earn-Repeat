# EcoChain – Recycle, Earn, Repeat ♻️

EcoChain is a blockchain-powered decentralized application (DApp) that incentivizes recycling behavior through QR code scanning and token rewards.

## 🌟 Features

- Scan QR codes on recycling bins
- Earn EcoTokens for every recycled item
- Redeem tokens for discounts or donations
- Admin dashboard to monitor data

## 🛠 Tech Stack

- **Frontend**: React.js
- **Backend**: Node.js + Express
- **Blockchain**: Solidity on Ethereum/Polygon
- **Wallet**: MetaMask integration
- **QR**: WebRTC + QR.js
- **Database**: MongoDB
- **Deployment**: Vercel + IPFS

## 🚀 How to Run Locally

### 1. Clone the Repository
```bash
git clone https://github.com/your-username/ecochain.git
cd ecochain
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Start the App
```bash
npm start
```

### 4. Smart Contracts (Optional)
Use Hardhat to deploy `EcoToken.sol` to a testnet.

## 📸 Screenshots
![EcoChain Screenshot](screenshot.png)

## 📜 License
MIT License